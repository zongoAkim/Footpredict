"use client";
import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

export default function AdminDashboard() {
  const [match, setMatch] = useState('');
  const [predictions, setPredictions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [authenticated, setAuthenticated] = useState(false);

  const authenticate = () => {
    if (login === 'admin' && password === 'secure123') {
      setAuthenticated(true);
    } else {
      alert('Identifiants incorrects');
    }
  };

  const getPrediction = async () => {
    if (!match.includes(' vs ')) return;
    setLoading(true);
    try {
      const res = await fetch('https://footpredict-backend.onrender.com/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ match })
      });
      const data = await res.json();
      if (res.ok) {
        setPredictions(prev => [data, ...prev]);
      } else {
        alert(data.detail || 'Erreur lors de la prédiction');
      }
    } catch (e) {
      alert('Erreur de connexion serveur');
    }
    setLoading(false);
  };

  const chartData = predictions.map((p, i) => ({
    name: `${p.homeTeam} vs ${p.awayTeam}`,
    home: p.prediction.chance.homeWin,
    draw: p.prediction.chance.draw,
    away: p.prediction.chance.awayWin
  }));

  if (!authenticated) {
    return (
      <div className="p-10 max-w-md mx-auto text-center">
        <h2 className="text-2xl font-bold mb-4">Connexion Admin</h2>
        <Input placeholder="Identifiant" value={login} onChange={e => setLogin(e.target.value)} className="mb-2" />
        <Input placeholder="Mot de passe" type="password" value={password} onChange={e => setPassword(e.target.value)} className="mb-4" />
        <Button onClick={authenticate}>Se connecter</Button>
      </div>
    );
  }

  return (
    <div className="p-4 max-w-5xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Dashboard Admin - FootPredict</h1>
      <Tabs defaultValue="predict">
        <TabsList className="mb-4">
          <TabsTrigger value="predict">Prédictions</TabsTrigger>
          <TabsTrigger value="stats">Statistiques</TabsTrigger>
        </TabsList>

        <TabsContent value="predict">
          <div className="flex gap-2 mb-4">
            <Input placeholder="Match (ex: PSG vs OM)" value={match} onChange={e => setMatch(e.target.value)} />
            <Button onClick={getPrediction} disabled={loading}>
              {loading ? 'Chargement...' : 'Prédire'}
            </Button>
          </div>

          <ScrollArea className="h-[600px]">
            {predictions.map((p, i) => (
              <Card key={i} className="mb-4">
                <CardContent className="p-4">
                  <h2 className="text-xl font-semibold mb-1">{p.homeTeam} vs {p.awayTeam}</h2>
                  <p><strong>Mi-temps</strong> : {p.prediction.halftimeScore}</p>
                  <p><strong>Score final</strong> : {p.prediction.fulltimeScore}</p>
                  <p><strong>Corners</strong> : {p.prediction.corners.home}-{p.prediction.corners.away} (Total {p.prediction.corners.total})</p>
                  <p><strong>Chances</strong> : {p.prediction.chance.homeWin}% - {p.prediction.chance.draw}% - {p.prediction.chance.awayWin}%</p>
                  <p className="mt-2 font-medium">Paris conseillés :</p>
                  <ul className="list-disc ml-6">
                    {p.prediction.safeBets.map((bet, j) => (
                      <li key={j}>{bet}</li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </ScrollArea>
        </TabsContent>

        <TabsContent value="stats">
          <div className="mt-4">
            <h2 className="text-xl font-bold mb-2">Analyse des chances</h2>
            <LineChart width={700} height={320} data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 50 }}>
              <CartesianGrid stroke="#ccc" strokeDasharray="3 3" />
              <XAxis dataKey="name" angle={-25} textAnchor="end" height={70} interval={0} />
              <YAxis domain={[0, 100]} />
              <Tooltip />
              <Line type="monotone" dataKey="home" stroke="#4ade80" name="Victoire Domicile %" />
              <Line type="monotone" dataKey="draw" stroke="#facc15" name="Match Nul %" />
              <Line type="monotone" dataKey="away" stroke="#f87171" name="Victoire Extérieur %" />
            </LineChart>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}